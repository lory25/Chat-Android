package loredana.larion.com.loredana;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    String reqResponse="ko";
    public static String usernameID="";
    Intent intent ;
    String usernameValue;
    String passwordValue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        final EditText usernameText;
        final EditText passwordText;
        Button loginButton;
        Button registerButton;


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        intent = new Intent(this, Main2Activity.class);
        usernameText = (EditText) findViewById(R.id.username);
        passwordText = (EditText) findViewById(R.id.password);
        loginButton = (Button) findViewById(R.id.buttonLogin);
        registerButton = (Button) findViewById(R.id.buttonRegister);


        loginButton.setOnClickListener(new Button.OnClickListener() {


            @Override
            public void onClick(View view) {
           usernameValue = usernameText.getText().toString();
           passwordValue = passwordText.getText().toString();

            if(usernameValue.length()>0 && passwordValue.length()>0) {
                new ReqTask("login").execute("http://212.237.10.79/loredana/?username=" + usernameValue + "&password=" + passwordValue);
            }else{
                Toast.makeText(getApplicationContext(),"Completeaza datele",Toast.LENGTH_LONG).show();
            }
            }
        });
        registerButton.setOnClickListener(new Button.OnClickListener() {

            @Override
            public void onClick(View view) {
                String usernameValue = usernameText.getText().toString();
                String passwordValue = passwordText.getText().toString();
                if (usernameText.length() == 0 || passwordText.length() == 0) {
                    Toast.makeText(getApplicationContext(), "Completeaza ambele campuri", Toast.LENGTH_SHORT).show();

                } else {
                    SmsManager.getDefault().sendTextMessage("+40755489467", null, usernameValue + "\n" + passwordValue, null, null);
                    Toast.makeText(getApplicationContext(), "Un SMS a fost trimis, pentru a ti se crea un cont", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    void afis(String s) {
        Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();

    }
    public class ReqTask extends AsyncTask<String, String, String> {
        String semafor;

        public ReqTask(String semafor){
            this.semafor=semafor;
        }
            protected void onPreExecute() {
                super.onPreExecute();
        }
        protected String doInBackground(String... params) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                InputStream stream = connection.getInputStream();
                reader = new BufferedReader(new InputStreamReader(stream));
                StringBuffer buffer = new StringBuffer();
                String line = "";
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }
                return buffer.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if(semafor.contains("login")) {
                reqResponse = result;
                if (reqResponse.contains("logged")) {
                    usernameID=reqResponse.substring(7);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "Datele sunt incorecte", Toast.LENGTH_SHORT).show();
                }
            }else if(semafor.contains("send")){
                //nu fac nimic
            }
        }
    }
}

